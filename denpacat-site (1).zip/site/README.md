# DENPACAT — Web Collage

A 3-page web collage built with plain HTML and CSS (no JavaScript) about DENPACAT, a composer, producer and songwriter, and the two collectives DENPACAT founded: Merelab Studio and SoundSight Audiovisual Expo. The look is an early-2000s pink "desktop window" style.

- `index.html`: the portfolio slide exported as a video, laid out with named `grid-template-areas`.
- `works.html`: a dense 6-column collage with one huge image and many tiny tags and icons.
- `studios.html`: an asymmetric `2fr 1fr 3fr` grid with stacked image fragments.

Every page has 10+ images with alt text, 3+ text blocks, custom fonts (Oswald and Comic Neue from Google Fonts), semantic tags (`nav`, `main`, `header`, `section`, `article`, `aside`, `figure`, `figcaption`) and links between the pages.

## Media credits

- Original: the portfolio slide design (made in Google Slides), avatar, MERELAB and SoundSight logos, buttons, icons, the portfolio video, and all images cropped from that video.
- Found: pink brain texture — source: _add link here_.
- Fonts: [Oswald](https://fonts.google.com/specimen/Oswald) and [Comic Neue](https://fonts.google.com/specimen/Comic+Neue), via Google Fonts.

## Tools and AI use

- Google Slides: designed the original portfolio page and exported it to video.
- FFmpeg and Python (Pillow): cropped the images used on the pages out of the video frames.
- Claude (Anthropic): helped write the HTML/CSS structure of the three pages, the grid layouts and this README. Example prompt: "Turn my Google Slides page into a 3-page CSS Grid website that meets these assignment requirements, with the video as the first page."
- Prettier: code formatting.
